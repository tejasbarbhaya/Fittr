//
//  ViewController.swift
//  FittrTest
//
//  Created by Tejash on 23/12/21.
//

import UIKit
import SVProgressHUD

class ViewController: UIViewController {

    @IBOutlet weak var collectionVw:UICollectionView!
    var gHeight:Double = 200.0
    
    var arrayGeners:GenerList?
    var arrayMovies:[MovieList]? = []
    var gblDispatchgroup:DispatchGroup!
    var dictFinal:[String:Any]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        collectionVw.delegate = self
        collectionVw.dataSource = self
        collectionVw.register(UINib.init(nibName: "GenerListCell", bundle: .main), forCellWithReuseIdentifier: "GenerListCellId")
        
        collectionVw.register(UINib(nibName: "GenerHeaderView", bundle: nil), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "GenerHeaderViewId")
        
        let layout = collectionVw.collectionViewLayout as? UICollectionViewFlowLayout // casting is required because UICollectionViewLayout doesn't offer header pin. Its feature of UICollectionViewFlowLayout
        layout?.sectionHeadersPinToVisibleBounds = true
        

        getNewsDetails()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }


    func getNewsDetails() {
        SVProgressHUD.show()
        
        Model.shared.getDiariesData(withCompletion: { [self] (response, errorMessage) in
            if let errorMessage = errorMessage {
                print(errorMessage)
                SVProgressHUD.dismiss()
                let alert = UIAlertController(title: "Network Error", message: "Unable to contact the server", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            else if let response = response {
                //print("response:: \(response.genres?.count)")
                gblDispatchgroup = DispatchGroup()
                gblDispatchgroup.enter()
                
                DispatchQueue.main.async {
                    arrayGeners = response
                    if let array = arrayGeners?.genres {
                        for obj in array {
                            self.getMoviesListForGener(obj.id!)
                        }
                    }
                }
            }
            gblDispatchgroup.notify(queue: .main) {
                //print("finalGeners: \(arrayGeners?.genres?.count) and finalMovies:\(arrayMovies?.count)")
                
                //Event will be called once all data will get downloaded
                collectionVw.reloadData()
            }
        })
    }
    
    func getMoviesListForGener(_ generId:Int) {
        Model.shared.getMoviesDataForGener(generId, withCompletion: { [self] (response, errorMessage) in
            SVProgressHUD.show()
            if let errorMessage = errorMessage {
                SVProgressHUD.dismiss()
                print(errorMessage.description)
                let alert = UIAlertController(title: "Network Error", message: "Unable to contact the server", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            else if let response = response {
                //print("response:: \(response.results?.first?.originalTitle)")
                arrayMovies?.append(response)
            }
            
            if arrayGeners?.genres?.count == arrayMovies?.count {
                //Time to leave the group
                SVProgressHUD.dismiss()
                gblDispatchgroup.leave()
                
            }
        })
    }
    
    
}

extension ViewController : UICollectionViewDataSource, UICollectionViewDelegate {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return arrayGeners?.genres?.count ?? 0
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView,cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "GenerListCellId",
            for: indexPath) as! GenerListCell
        let gener = arrayGeners?.genres?[indexPath.section]
        //gener.id
        
        let movieList = arrayMovies?.filter{ $0.id == gener?.id!}
        cell.movieList = (movieList?.first)!
        cell.callBack = { arg in
            self.collectionVw.collectionViewLayout.invalidateLayout()
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,viewForSupplementaryElementOfKind kind: String,at indexPath: IndexPath) -> UICollectionReusableView {
        
        guard kind == UICollectionView.elementKindSectionHeader else {
            return UICollectionReusableView()
        }
        
        let view = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "GenerHeaderViewId", for: indexPath) as! GenerHeaderView
        
        if let obj = arrayGeners?.genres?[indexPath.section] {
            view.lblName.text = obj.name!
        }
        return view
    }
    
    @objc func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        let size = CGSize(width: collectionView.bounds.size.width - 16, height: 50.0)
        return size
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(indexPath.item)
        
    }
}

extension ViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: collectionView.bounds.size.width, height: CGFloat(gHeight))
        /*let sectionInset = (collectionViewLayout as! UICollectionViewFlowLayout).sectionInset
        let referenceWidth: CGFloat = collectionView.bounds.size.width// Approximate height of your cell
        let referenceHeight = collectionView.safeAreaLayoutGuide.layoutFrame.height
            - sectionInset.top
            - sectionInset.bottom
            - collectionView.contentInset.top
            - collectionView.contentInset.bottom
        print("outer width:\(referenceWidth) and outer height:\(referenceHeight)")
        if let cell = collectionView.cellForItem(at: indexPath) as? GenerListCell {
            var height = cell.layoutConstStackVw.constant
            print("outer cell size: \(cell.contentView.bounds) and height:\(height)")
            height = cell.contentView.bounds.height
            return CGSize(width: referenceWidth, height: height)
        }
        return CGSize(width: referenceWidth, height: referenceHeight)*/
    }
    
    func collectionView(_ collectionView: UICollectionView,layout collectionViewLayout: UICollectionViewLayout,minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 8
    }
    
    func collectionView(_ collectionView: UICollectionView,layout collectionViewLayout: UICollectionViewLayout,minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout,insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
    }
    
}
