//
//  WebRequester.swift
//  FittrTest
//
//  Created by Tejash on 21/12/21.
//


import Foundation
import Alamofire

class WebRequester {
    
    static let shared = WebRequester()
    
    func request(toURL url: String, withParameters param: Parameters?, alongWithcompletion completion: @escaping (_ result: Any?, _ error: Error?) -> Void) {
        AF.request(url, method: .get, parameters: param)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseJSON { response in
                switch response.result {
                    case .success:
                        completion(response.value, nil)
                    case let .failure(error):
                        completion(nil, error)
                }
        }
        .responseString { response in
            //print("==============================")
            //print("Response Time:\(String(describing: response.metrics?.taskInterval))")
            //print("URL: \(url)")
            //print("param: \(String(describing: param))")
            //print("Response String: \(response.value ?? "Something went wrong")")
            //print("==============================")
        }
    }
}
