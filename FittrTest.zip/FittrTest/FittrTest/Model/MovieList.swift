//
//  MovieList.swift
//  FittrTest
//
//  Created by Tejash on 23/12/21.
//

import Foundation

// MARK: - MovieList
class MovieList: Codable {
    var id, page: Int?
    var results: [Result]?
    var totalPages, totalResults: Int?

    enum CodingKeys: String, CodingKey {
        case id, page, results
        case totalPages = "total_pages"
        case totalResults = "total_results"
    }

    init(id: Int?, page: Int?, results: [Result]?, totalPages: Int?, totalResults: Int?) {
        self.id = id
        self.page = page
        self.results = results
        self.totalPages = totalPages
        self.totalResults = totalResults
    }
}

// MARK: MovieList convenience initializers and mutators

extension MovieList {
    convenience init(data: Data) throws {
        let me = try newJSONDecoder().decode(MovieList.self, from: data)
        self.init(id: me.id, page: me.page, results: me.results, totalPages: me.totalPages, totalResults: me.totalResults)
    }

    convenience init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    convenience init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        id: Int?? = nil,
        page: Int?? = nil,
        results: [Result]?? = nil,
        totalPages: Int?? = nil,
        totalResults: Int?? = nil
    ) -> MovieList {
        return MovieList(
            id: id ?? self.id,
            page: page ?? self.page,
            results: results ?? self.results,
            totalPages: totalPages ?? self.totalPages,
            totalResults: totalResults ?? self.totalResults
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

import Foundation

// MARK: - Result
class Result: Codable {
    var adult: Bool?
    var backdropPath: String?
    var genreIDS: [Int]?
    var id: Int?
    //var originalLanguage: OriginalLanguage?
    var originalLanguage: String?
    var originalTitle, overview: String?
    var popularity: Double?
    var posterPath, releaseDate, title: String?
    var video: Bool?
    var voteAverage: Double?
    var voteCount: Int?

    enum CodingKeys: String, CodingKey {
        case adult
        case backdropPath = "backdrop_path"
        case genreIDS = "genre_ids"
        case id
        case originalLanguage = "original_language"
        case originalTitle = "original_title"
        case overview, popularity
        case posterPath = "poster_path"
        case releaseDate = "release_date"
        case title, video
        case voteAverage = "vote_average"
        case voteCount = "vote_count"
    }

    init(adult: Bool?, backdropPath: String?, genreIDS: [Int]?, id: Int?, originalLanguage: String?, originalTitle: String?, overview: String?, popularity: Double?, posterPath: String?, releaseDate: String?, title: String?, video: Bool?, voteAverage: Double?, voteCount: Int?) {
        self.adult = adult
        self.backdropPath = backdropPath
        self.genreIDS = genreIDS
        self.id = id
        self.originalLanguage = originalLanguage
        self.originalTitle = originalTitle
        self.overview = overview
        self.popularity = popularity
        self.posterPath = posterPath
        self.releaseDate = releaseDate
        self.title = title
        self.video = video
        self.voteAverage = voteAverage
        self.voteCount = voteCount
    }
}



extension Result {
    convenience init(data: Data) throws {
        let me = try newJSONDecoder().decode(Result.self, from: data)
        self.init(adult: me.adult, backdropPath: me.backdropPath, genreIDS: me.genreIDS, id: me.id, originalLanguage: me.originalLanguage, originalTitle: me.originalTitle, overview: me.overview, popularity: me.popularity, posterPath: me.posterPath, releaseDate: me.releaseDate, title: me.title, video: me.video, voteAverage: me.voteAverage, voteCount: me.voteCount)
    }

    convenience init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    convenience init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        adult: Bool?? = nil,
        backdropPath: String?? = nil,
        genreIDS: [Int]?? = nil,
        id: Int?? = nil,
        originalLanguage: String?? = nil,
        originalTitle: String?? = nil,
        overview: String?? = nil,
        popularity: Double?? = nil,
        posterPath: String?? = nil,
        releaseDate: String?? = nil,
        title: String?? = nil,
        video: Bool?? = nil,
        voteAverage: Double?? = nil,
        voteCount: Int?? = nil
    ) -> Result {
        return Result(
            adult: adult ?? self.adult,
            backdropPath: backdropPath ?? self.backdropPath,
            genreIDS: genreIDS ?? self.genreIDS,
            id: id ?? self.id,
            originalLanguage: originalLanguage ?? self.originalLanguage,
            originalTitle: originalTitle ?? self.originalTitle,
            overview: overview ?? self.overview,
            popularity: popularity ?? self.popularity,
            posterPath: posterPath ?? self.posterPath,
            releaseDate: releaseDate ?? self.releaseDate,
            title: title ?? self.title,
            video: video ?? self.video,
            voteAverage: voteAverage ?? self.voteAverage,
            voteCount: voteCount ?? self.voteCount
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}


import Foundation

enum OriginalLanguage: String, Codable {
    case en = "en"
    case ja = "ja"
    case pl = "pl"
    case ru = "ru"
    case hi = "hi"
}
