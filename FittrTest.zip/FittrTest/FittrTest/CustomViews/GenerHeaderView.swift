//
//  GenerHeaderView.swift
//  FittrTest
//
//  Created by Tejash on 23/12/21.
//

import UIKit

class GenerHeaderView: UICollectionViewCell {
    @IBOutlet weak var lblName:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
