//
//  GenerListCell.swift
//  FittrTest
//
//  Created by Tejash on 23/12/21.
//

import UIKit
import SDWebImage

class GenerListCell: UICollectionViewCell {
    @IBOutlet weak var cellCollectionvW:UICollectionView!
    @IBOutlet weak var layoutConstStackVw:NSLayoutConstraint!
    
    var callBack:((Double) -> Void)?
    var gWidth:Double = 150.0
    var gHeight:Double = 200.0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        cellCollectionvW.delegate = self
        cellCollectionvW.dataSource = self
        cellCollectionvW.register(UINib.init(nibName: "MovieCell", bundle: .main), forCellWithReuseIdentifier: "MovieCellId")
    }
    
    var movieList : MovieList? = nil {
        didSet{
            
        }
    }
    
//    override func preferredLayoutAttributesFitting(_ layoutAttributes: UICollectionViewLayoutAttributes) -> UICollectionViewLayoutAttributes {
//        let targetSize = CGSize(width: layoutAttributes.frame.width, height:layoutAttributes.frame.height)
//        layoutAttributes.frame.size = contentView.systemLayoutSizeFitting(targetSize, withHorizontalFittingPriority: .required, verticalFittingPriority: .fittingSizeLevel)
//        print("\n GenerListCell preferredLayoutAttributesFitting :\(layoutAttributes.frame)")
//        return layoutAttributes
//    }
}


extension GenerListCell : UICollectionViewDataSource, UICollectionViewDelegate {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movieList?.results?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView,cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "MovieCellId",
            for: indexPath) as! MovieCell
        
        cell.lblMovieName.text = movieList?.results?[indexPath.row].title!
        cell.lblMovieDescription.text = movieList?.results?[indexPath.row].overview!
        cell.imgView.sd_setImage(with: URL(string: APPURL.getImageBaseUrl + (movieList?.results?[indexPath.row].backdropPath)!), placeholderImage: UIImage(named: "ic_moviePlaceholder"), options: SDWebImageOptions.progressiveLoad, context: nil)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(indexPath.item)
        //collectionView.collectionViewLayout.invalidateLayout()
        callBack!(0.0)
    }
}

extension GenerListCell: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: gWidth, height: gHeight)
    }
    /*func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        /*let sectionInset = (collectionViewLayout as! UICollectionViewFlowLayout).sectionInset
        let referenceHeight: CGFloat = 100 // Approximate height of your cell
        let referenceWidth = collectionView.safeAreaLayoutGuide.layoutFrame.width
            - sectionInset.left
            - sectionInset.right
            - collectionView.contentInset.left
            - collectionView.contentInset.right
        return CGSize(width: referenceWidth, height: referenceHeight)*/
        let sectionInset = (collectionViewLayout as! UICollectionViewFlowLayout).sectionInset
        let referenceWidth: CGFloat = CGFloat(self.gWidth)// Approximate height of your cell
        let referenceHeight = collectionView.safeAreaLayoutGuide.layoutFrame.height
            - sectionInset.top
            - sectionInset.bottom
            - collectionView.contentInset.top
            - collectionView.contentInset.bottom
        print("width:\(referenceWidth) and height:\(referenceHeight)")
        if let cell = collectionView.cellForItem(at: indexPath) as? MovieCell {
            let height = cell.layoutConstImgvw.constant + cell.layoutConstLblMovie.constant + cell.layoutConstLblDescription.constant
            print("cell size: \(cell.contentView.bounds) and height:\(height)")
            return CGSize(width: referenceWidth, height: height)
        }
        
        return CGSize(width: referenceWidth, height: referenceHeight)
    }*/
    
    func collectionView(_ collectionView: UICollectionView,layout collectionViewLayout: UICollectionViewLayout,minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 8
    }
    
    func collectionView(_ collectionView: UICollectionView,layout collectionViewLayout: UICollectionViewLayout,minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout,insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.init(top: 0, left: 10, bottom: 0, right: 10)
    }
}
