//
//  MovieCell.swift
//  FittrTest
//
//  Created by Tejash on 23/12/21.
//

import UIKit
import SDWebImage

class MovieCell: UICollectionViewCell, UIGestureRecognizerDelegate {
    
    @IBOutlet weak var lblMovieName:UILabel!
    @IBOutlet weak var imgView:UIImageView!
    @IBOutlet weak var lblMovieDescription:UILabel!
    
    @IBOutlet weak var layoutConstLblMovie:NSLayoutConstraint!
    @IBOutlet weak var layoutConstImgvw:NSLayoutConstraint!
    @IBOutlet weak var layoutConstLblDescription:NSLayoutConstraint!

    override var isSelected: Bool {
        didSet{
            lblMovieDescription.isHidden = !isSelected
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        lblMovieDescription.isHidden = !isSelected
    }
        
    override func preferredLayoutAttributesFitting(_ layoutAttributes: UICollectionViewLayoutAttributes) -> UICollectionViewLayoutAttributes {
        let targetSize = CGSize(width: layoutAttributes.frame.width, height: 0)
        layoutAttributes.frame.size = contentView.systemLayoutSizeFitting(targetSize, withHorizontalFittingPriority: .required, verticalFittingPriority: .fittingSizeLevel)
        return layoutAttributes
    }
}
