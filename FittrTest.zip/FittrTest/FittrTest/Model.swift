//
//  Model.swift
//  DevStreeTest
//
//  Created by Tejash on 23/12/21.
//

import Foundation
import UIKit

class Model {
    static let shared = Model()
    
    //MARK: - API Calls
    func getDiariesData(withCompletion completion: @escaping (_ message: GenerList?,_ errorMessage: String?) -> Void) {
        WebRequester.shared.request(toURL: APPURL.getGenerList, withParameters: nil) { (response, error) in
            if let error = error {
                completion(nil,error.localizedDescription)
            }
            else if let response = response {
                do {
                    if let theJSONData = try?  JSONSerialization.data(withJSONObject: response as Any,options: .prettyPrinted),
                       let theJSONText = String(data: theJSONData,
                                                encoding: .utf8) {
                        let dairyDetails = try GenerList(theJSONText)
                        completion(dairyDetails, nil)
                    }
                }
                catch {
                    completion(nil, error.localizedDescription)
                }            }
            else {
                completion(nil,"data not found")
            }
        }
    }
    
    func getMoviesDataForGener(_ generID:Int, withCompletion completion: @escaping (_ message: MovieList?,_ errorMessage: String?) -> Void) {
        WebRequester.shared.request(toURL: APPURL.getMovieList + "/\(generID)/movies" + APPURL.apiKey, withParameters: nil) { (response, error) in
            if let error = error {
                completion(nil,error.localizedDescription)
            }
            else if let response = response {
                do {
                    if let theJSONData = try?  JSONSerialization.data(withJSONObject: response as Any,options: .prettyPrinted),
                       let theJSONText = String(data: theJSONData,
                                                encoding: .utf8) {
                        let movieList = try MovieList(theJSONText)
                        completion(movieList, nil)
                    }
                }
                catch {
                    completion(nil, error.localizedDescription)
                }            }
            else {
                completion(nil,"data not found")
            }
        }
    }
}
